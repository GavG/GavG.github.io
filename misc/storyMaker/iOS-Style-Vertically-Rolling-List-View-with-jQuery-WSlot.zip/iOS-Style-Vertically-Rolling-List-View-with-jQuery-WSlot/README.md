# WSlot
jQuery plugin to create a slot rolling list

http://danartinho.github.io/WSlot/
